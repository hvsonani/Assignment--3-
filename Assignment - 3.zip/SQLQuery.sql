
/* Q-1) Create two employee tables with the following columns
    first name, last name, domain, login One table will hold male
    employees the other will hold female create the tables in toad
    and generate the ddl. */ 

 -- Table Male_Employees--

 Use Assignment

CREATE TABLE [Male_Employees]
(
 [First Name] Varchar(50) NULL,
 [Last Name] Varchar(50) NULL,
 [Domain] Varchar(50) NULL,
 [Login] Varchar(50) NULL
)
go

-- Table Female_Employees

CREATE TABLE [Female_Employees]
(
 [First Name] Varchar(50) NULL,
 [Last Name] Varchar(50) NULL,
 [Domain] Varchar(50) NULL,
 [Login] Varchar(50) NULL
)
go
 
-- Q-5) BCP in scripting table --

use Assignment

CREATE TABLE [dbo].[BCPINemployee]
(
	[emp_id] [char](9) NOT NULL,
	[fname] [varchar](20) NOT NULL,
	[minit] [char](1) NULL,
	[lname] [varchar](30) NOT NULL,
	[job_id] [smallint] NOT NULL,
	[job_lvl] [tinyint] NULL,
	[pub_id] [char](4) NOT NULL,
	[hire_date] [datetime] NOT NULL
	)

select * from BCPINemployee


-- Q-6) Show the titles with more than one author --

use pubs

select t.title, COUNT(ta.au_id)[No of authors]
from titles t
INNER JOIN titleauthor ta 
on t.title_id = ta.title_id
group by t.title
having COUNT(ta.au_id) > 1

-- Q-7) Show the sql to show all the authors with more than one book --

select a.au_fname [First Name], a.au_lname [Last Name], COUNT(ta.title_id)[No of books]
from authors a
INNER JOIN titleauthor ta
on a.au_id = ta.au_id
group by a.au_fname, a.au_lname
having COUNT(ta.title_id) >1


-- Q-8) Show the sql to show the publishers with no titles --

select p.pub_id, p.pub_name, t.title  
from publishers p
LEFT JOIN titles t
on p.pub_id = t.pub_id
where t.title is NULL






